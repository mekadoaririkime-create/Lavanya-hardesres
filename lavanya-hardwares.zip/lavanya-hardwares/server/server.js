const express = require('express')
const app = express()

app.get('/', (req, res) => {
  res.send('Lavanya Hardwares API')
})

app.listen(5000, () => console.log('Server running'))
