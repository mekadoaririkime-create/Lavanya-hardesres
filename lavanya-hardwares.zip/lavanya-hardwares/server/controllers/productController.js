const getProducts = async (req, res) => {
  res.json([])
}

module.exports = { getProducts }
