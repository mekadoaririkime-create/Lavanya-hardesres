export default function Home() {
  return (
    <div>
      <h1>Lavanya Hardwares</h1>
      <p>Pipes, sinks, tools and hardware products.</p>
    </div>
  )
}
