export default function Navbar() {
  return <nav>Lavanya Hardwares</nav>
}
